import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
const require=createRequire(import.meta.url);
const {chromium}=require('playwright');
const root=path.dirname(new URL(import.meta.url).pathname),base=process.env.PREVIEW_URL||'http://127.0.0.1:8769';
const browser=await chromium.launch({headless:true,...(process.env.CHROME_EXECUTABLE_PATH?{executablePath:process.env.CHROME_EXECUTABLE_PATH}:{})});
const results=[];
try{
for(const width of [390,1440])for(const rm of ['no-preference','reduce']){
 const context=await browser.newContext({viewport:{width,height:900},reducedMotion:rm});
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 await page.goto(base+'/wire.html');await page.waitForFunction(()=>window.__c8Motion?.ready);await page.locator('#tAnnot').count().then(async n=>{if(n)await page.locator('#tAnnot').click();});
 await page.evaluate(()=>document.body.classList.add('no-annot'));
 // Fix the animation at a real timeline time, independent of wall-clock screenshots.
 await page.evaluate(()=>{for(const a of document.getAnimations()){a.pause();a.currentTime=100;}});
 if(!process.env.C8_READ_ONLY)await page.screenshot({path:`${root}/wire-${width}-${rm}-100ms.png`});
 const view=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,heroVisible:getComputedStyle(document.querySelector('.hcard.main')).opacity,rm:window.__c8Motion.reduced(),active:document.getAnimations().filter(a=>a.playState==='running').length}));
 for(const id of ['ch01','ch02','ch03','ch04','bridge','s12']){
  await page.locator('#'+id).scrollIntoViewIfNeeded();await page.waitForTimeout(120);
 }
 // Accordion screens move without losing labels or duplicating video controllers.
 await page.locator('#ch02-2 summary').click();await page.waitForTimeout(80);
 await page.locator('#ch02-1 summary').click();await page.waitForTimeout(80);
 await page.locator('#ch01-2 summary').click();await page.waitForTimeout(80);
 await page.locator('#ch01-1 summary').click();await page.waitForTimeout(80);
 await page.locator('#jobPick button').first().click();
 await page.locator('#expName').fill('가상 이름');
 if(width===390){await page.locator('#expOpen').click();await page.waitForTimeout(100);await page.locator('#expClose').click();}
 await page.locator('#bridge').scrollIntoViewIfNeeded();
 await page.evaluate(()=>{for(const a of document.getAnimations()){a.pause();a.currentTime=100;}});
 if(!process.env.C8_READ_ONLY)await page.screenshot({path:`${root}/bridge-${width}-${rm}-100ms.png`});
 const observed=await page.evaluate(()=>({history:window.__c8Motion.history,videoCount:document.querySelectorAll('video').length,overflow:document.documentElement.scrollWidth-innerWidth,previewName:document.querySelector('#pvName').textContent,video:window.__c8Motion.media.map(m=>m.getState()),staticMotion:window.__c8Motion.history.filter(x=>/s2|s3|s10|s13/.test(x.target))}));
 results.push({width,reducedMotion:rm,view,...observed,errors});await context.close();
}
// Compare transform and opacity numerically at non-rest points, not just identical endpoints.
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto(base+'/compare.html');await page.waitForFunction(()=>window.__compare?.ready);
const parity=[];
for(const t of [.033,.067,.1,.15,.2,3.033,3.067,3.1,3.2]){
 await page.evaluate(t=>window.__compare.seek(t),t);await page.waitForTimeout(30);
 parity.push(await page.evaluate(t=>{
  const words=[...document.querySelectorAll('.web-word')],doc=document.querySelector('#reel').contentDocument;
  const tr=el=>{const c=getComputedStyle(el);const m=new DOMMatrix(c.transform);return {y:m.m42,scale:m.a,opacity:+c.opacity};};
  const web=t<3?words.map(tr):[tr(document.querySelector('#webLogo'))];
  const reel=t<3?[...doc.querySelectorAll('.word')].map(tr):[tr(doc.querySelector('#endLogo'))];
  return {t,web,reel,maxError:Math.max(...web.flatMap((v,i)=>[Math.abs(v.opacity-reel[i].opacity),Math.abs(v.scale-reel[i].scale),Math.abs(v.y/window.__compare.wordDistance-reel[i].y/48)]))};
 },t));
}
await page.evaluate(()=>window.__compare.seek(.1));if(!process.env.C8_READ_ONLY)await page.screenshot({path:`${root}/compare-100ms.png`,fullPage:true});
results.push({comparison:true,parity,errors});
// Actual Chrome CPU throttling, LoAF observation and frame cadence cover the full nine-scene pass.
const perf=await browser.newPage({viewport:{width:390,height:844}}),cdp=await perf.context().newCDPSession(perf);
await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
await perf.addInitScript(()=>{window.__perf={loaf:[],raf:[]};try{new PerformanceObserver(l=>window.__perf.loaf.push(...l.getEntries().map(e=>({startTime:e.startTime,duration:e.duration,blockingDuration:e.blockingDuration})))).observe({type:'long-animation-frame',buffered:true});}catch{}let last;function tick(t){if(last)window.__perf.raf.push(t-last);last=t;requestAnimationFrame(tick);}requestAnimationFrame(tick);});
await perf.goto(base+'/wire.html');await perf.waitForFunction(()=>window.__c8Motion?.ready);await perf.evaluate(()=>document.body.classList.add('no-annot'));
for(const id of ['s1','ch01','ch02','ch03','ch04','bridge','ch05','exp','s12']){await perf.locator('#'+id).scrollIntoViewIfNeeded();await perf.waitForTimeout(500);}
const performanceResult=await perf.evaluate(()=>({supported:PerformanceObserver.supportedEntryTypes.includes('long-animation-frame'),...window.__perf}));
performanceResult.cpuSlowdown=4;performanceResult.durationMs=performanceResult.raf.reduce((a,b)=>a+b,0);performanceResult.rafOver50=performanceResult.raf.filter(x=>x>50).length;performanceResult.loafCount=performanceResult.loaf.length;
results.push({performance:performanceResult});
if(!process.env.C8_READ_ONLY)fs.writeFileSync(`${root}/browser-results.json`,JSON.stringify(results,null,2));
const failures=results.filter(r=>r.errors?.length||r.overflow>0||r.view?.overflow>0||r.parity?.some(p=>p.maxError>.025));
console.log(JSON.stringify({results:results.map(r=>r.comparison?{parity:r.parity.map(p=>({t:p.t,maxError:p.maxError})),errors:r.errors}:r.performance?{cpu:4,loaf:r.performance.loafCount,rafOver50:r.performance.rafOver50,durationMs:r.performance.durationMs}:{width:r.width,rm:r.reducedMotion,overflow:r.overflow,errors:r.errors,videoCount:r.videoCount}),failures:failures.length},null,2));
if(failures.length)process.exitCode=1;
}finally{await browser.close();}
