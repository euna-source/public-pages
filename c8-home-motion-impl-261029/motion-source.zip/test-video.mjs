import {createRequire} from 'node:module';import fs from 'node:fs';
const require=createRequire(import.meta.url);const {chromium}=require('playwright');
const root=new URL('.',import.meta.url).pathname;
const browser=await chromium.launch({headless:true,...(process.env.CHROME_EXECUTABLE_PATH?{executablePath:process.env.CHROME_EXECUTABLE_PATH}:{})});
const page=await browser.newPage({viewport:{width:390,height:844}}),checks=[];
try{
 await page.route('**/fixture.mp4',r=>r.fulfill({status:200,contentType:'video/mp4',body:fs.readFileSync(root+'respect-optimized.mp4')}));
 await page.goto('http://127.0.0.1:8769/wire.html');await page.waitForFunction(()=>window.__c8Motion?.ready);
 await page.evaluate(async()=>{const {mountVideo}=await import('./home-motion.mjs');const host=document.createElement('div');host.id='fixture';host.style.cssText='height:300px;margin-top:2000px';document.body.append(host);window.fixture=mountVideo(host,{src:'fixture.mp4',fullSrc:'fixture.mp4',label:'비공개 시험 영상',posterText:'시험 포스터'});});
 function ok(name,pass,extra){checks.push({name,pass,...extra});if(!pass)throw Error(name);}
 ok('far video not loaded',!(await page.evaluate(()=>window.fixture.getState().loaded)));
 await page.evaluate(()=>window.scrollTo(0,document.querySelector('#fixture').offsetTop-innerHeight-1500));await page.waitForTimeout(150);
 ok('outside preload margin not loaded',!(await page.evaluate(()=>window.fixture.getState().loaded)));
 await page.evaluate(()=>window.scrollTo(0,document.querySelector('#fixture').offsetTop-innerHeight-1100));await page.waitForTimeout(300);
 ok('within 1200px margin loaded and paused',await page.evaluate(()=>window.fixture.getState().loaded&&window.fixture.video.paused));
 await page.locator('#fixture').scrollIntoViewIfNeeded();await page.waitForFunction(()=>!window.fixture.video.paused);
 ok('visible real media plays',true);
 await page.locator('#fixture button').click();await page.waitForTimeout(100);ok('user pause',await page.evaluate(()=>window.fixture.video.paused&&window.fixture.getState().paused));
 await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(100);await page.locator('#fixture').scrollIntoViewIfNeeded();await page.waitForTimeout(200);
 ok('pause survives viewport exit',await page.evaluate(()=>window.fixture.video.paused));
 await page.locator('#fixture button').click();await page.waitForFunction(()=>!window.fixture.video.paused);
 await page.emulateMedia({reducedMotion:'reduce'});await page.waitForFunction(()=>window.fixture.video.paused);ok('dynamic reduce cancels auto playback',await page.evaluate(()=>window.fixture.video.paused));
 await page.locator('#fixture button').click();await page.waitForFunction(()=>!window.fixture.video.paused);
 await page.evaluate(()=>document.body.classList.toggle('bar-hidden'));await page.waitForTimeout(100);ok('reduced-motion explicit play survives unrelated class',await page.evaluate(()=>!window.fixture.video.paused));
 await page.evaluate(()=>window.dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true})));ok('pagehide pause',await page.evaluate(()=>window.fixture.video.paused));
 await page.evaluate(()=>window.dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true})));await page.waitForFunction(()=>!window.fixture.video.paused);ok('bfcache recovery',true);
 await page.emulateMedia({reducedMotion:'no-preference'});
 await page.evaluate(()=>window.fixture.playFull());await page.waitForFunction(()=>!window.fixture.video.paused);ok('full film starts only on explicit request',await page.evaluate(()=>window.fixture.getState().fullMode&&!window.fixture.video.muted&&!window.fixture.video.loop));
 await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(120);await page.locator('#fixture').scrollIntoViewIfNeeded();await page.waitForTimeout(120);ok('sound film stays paused after viewport return',await page.evaluate(()=>window.fixture.video.paused));
 await page.locator('#fixture button').click();await page.waitForFunction(()=>!window.fixture.video.paused);await page.emulateMedia({reducedMotion:'reduce'});await page.waitForFunction(()=>window.fixture.video.paused);ok('dynamic reduce pauses full film',await page.evaluate(()=>window.fixture.video.paused));await page.emulateMedia({reducedMotion:'no-preference'});await page.waitForTimeout(150);ok('full film does not resume sound after reduce is disabled',await page.evaluate(()=>window.fixture.video.paused));
 // Force an asynchronous autoplay rejection to exercise the real catch branch.
 await page.evaluate(()=>{window.fixture.dispose();window.originalPlay=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){return Promise.reject(new DOMException('test','NotAllowedError'));};});
 await page.evaluate(async()=>{const {mountVideo}=await import('./home-motion.mjs');window.blocked=mountVideo(document.querySelector('#fixture'),{src:'fixture.mp4',label:'차단 시험',posterText:'포스터'});});await page.waitForTimeout(300);
 ok('autoplay rejected exposes play button',await page.locator('#fixture .media-state').innerText().then(t=>t.includes('자동재생이 막혔어요')));
 await page.evaluate(()=>HTMLMediaElement.prototype.play=window.originalPlay);await page.locator('#fixture button').click();await page.waitForFunction(()=>!window.blocked.video.paused);ok('blocked playback recovers manually',true);
 // Pending play must not restart a video after leaving the viewport.
 await page.evaluate(()=>{window.blocked.dispose();HTMLMediaElement.prototype.play=function(){return new Promise(r=>window.finishPlay=r);};});
 await page.evaluate(async()=>{const {mountVideo}=await import('./home-motion.mjs');window.race=mountVideo(document.querySelector('#fixture'),{src:'fixture.mp4',label:'경합 시험',posterText:'포스터'});});await page.waitForFunction(()=>window.finishPlay);
 await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(100);await page.evaluate(()=>{window.finishPlay();HTMLMediaElement.prototype.play=window.originalPlay;});await page.waitForTimeout(100);
 ok('stale play promise cannot resume offscreen',await page.evaluate(()=>window.race.video.paused&&!window.race.getState().visible));
 if(!process.env.C8_READ_ONLY)fs.writeFileSync(root+'video-tests.json',JSON.stringify({passed:true,checks},null,2));console.log(JSON.stringify(checks,null,2));
}catch(e){if(!process.env.C8_READ_ONLY)fs.writeFileSync(root+'video-tests.json',JSON.stringify({passed:false,checks,error:e.message},null,2));throw e;}finally{await browser.close();}
