from pathlib import Path
import re, shutil

root=Path(__file__).parent
out=root/'preview'
out.mkdir(exist_ok=True)
s=(root/'original.html').read_text()
s=s.replace('<title>C8 홈 와이어 v0.10</title>','<title>C8 홈 모션 미리보기</title>\n<meta name="robots" content="noindex,nofollow">\n<link rel="stylesheet" href="generated/tokens.css">\n<link rel="stylesheet" href="home-motion.css">')
# Existing entrance effects would create extra protagonists. Keep those headings static.
s=s.replace('transition:transform .22s cubic-bezier(.2,.7,.2,1)','transition:transform var(--spatial-default-duration) var(--spatial-default-ease)')
s=s.replace('transition:transform .5s cubic-bezier(.2,.7,.2,1),opacity .5s ease-out','transition:none')
s=s.replace('transform:translateY(32px);opacity:0','transform:none;opacity:1')
s=s.replace('transition:opacity .3s ease-out','transition:none')
s=s.replace('opacity:0;transition:opacity .4s ease-out','opacity:1;transition:none')
s=s.replace('transition:opacity .2s','transition:opacity var(--effects-fast-duration) var(--effects-fast-ease)')
s=s.replace('visibility 0s linear .22s','visibility 0s linear var(--spatial-default-duration)')
s=re.sub(r'\.screen\.vid\.loaded \.phone \.ph::(?:before|after)\{[^}]+\}', '',s)
s=s.replace('animation:prog 60s linear infinite','animation:none')
# All application demos remain explicitly low-fidelity wire content.
s=s.replace('data-scr="\'+it.scr+\'"','data-scr="\'+it.scr+\'"')
s=s.replace('    var v=!!d.dataset.video;', '    if(window.c8ScreenChanged) window.c8ScreenChanged(scr, d);\n    var v=!!d.dataset.video;')
s=s.replace('    if(saveUrl) hideSaveImg();','    if(window.c8PreviewChanged) window.c8PreviewChanged();\n    if(saveUrl) hideSaveImg();')
# Respect player is replaced by the real video lifecycle, not fake CSS feed animation.
s=s.replace('function setVid(sc,play){ if(!sc) return;', 'function setVid(sc,play){ if(!sc) return; if(window.c8VideoRequest) window.c8VideoRequest(sc,play);')
s=s.replace('function setPlaying(on,label){\n    playing=on;', 'function setPlaying(on,label){\n    if(window.c8EpisodeRequest){ window.c8EpisodeRequest(on); return; }\n    playing=on;')
s=s.replace('var e=EPS[n-1]; if(!e) return; current=n;', 'var e=EPS[n-1]; if(!e) return; current=n; if(window.c8FeaturedChanged) window.c8FeaturedChanged(n);')
s=s.replace('    var snd=$("pSound");','    if(window.c8EpisodeRequest) return;\n    var snd=$("pSound");')
s=re.sub(r'  \$\("pPause"\)\.addEventListener\("click",function\(\)\{.*?(?=  /\* 직군 칩:)', '', s, flags=re.S)
# Disable the legacy simulated player even before modules or the media manifest load.
s=re.sub(r'  function setPlaying\(on,label\)\{.*?(?=  /\* 직군 칩:)', '  function setPlaying(on,label){}\n\n', s, flags=re.S)
s=s.replace('if(opt && opt.sound){ snd.setAttribute("aria-pressed","true"); snd.textContent="소리 끄기"; }','')
s=s.replace('id="pState">무음 자동 재생 중','id="pState">영상 원본 확인 전')
s=s.replace('id="pSound" aria-pressed="false">소리 켜기','id="pSound">소리 켜고 전체 보기')
s=s.replace('id="pPause"','id="pPause" hidden').replace('id="pBar"','id="pBar" hidden')
s=s.replace('rootMargin:"200px 0px"','rootMargin:"1200px 0px"')
s=s.replace('<body', '<body',1)
s=s.replace('</body>','<script type="module" src="home-motion.mjs"></script>\n</body>')
(out/'wire.html').write_text(s)
shutil.copy(root/'motion-tokens.json',out/'motion-tokens.json')
shutil.copy(root/'generate.mjs',out/'generate.mjs')
print('Built motion copy; original is unchanged')
