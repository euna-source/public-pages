import assert from 'node:assert/strict';
import fs from 'node:fs';
import {generate,response,settle} from './generate.mjs';
import {springs,transitions,gsapTransition,stagger} from './preview/generated/motion.mjs';
const t=JSON.parse(fs.readFileSync(new URL('./motion-tokens.json',import.meta.url)));
const a=generate(t),b=generate(t);assert.equal(a.css,b.css);assert.equal(a.js,b.js);
const expected={'spatial.fast':[800,.6],'spatial.default':[700,.9],'spatial.slow':[300,.9],'effects.fast':[3800,1],'effects.default':[1600,1],'effects.slow':[800,1]};
for(const [name,[k,z]] of Object.entries(expected)){
  const s=springs[name], m=transitions[name];
  assert.equal(s.stiffness,k);assert.equal(s.dampingRatio,z);assert.equal(m.damping,2*z*Math.sqrt(k));
  assert(!('duration'in m));assert(!('bounce'in m));assert.equal(m.mass,1);
  const g=gsapTransition(name);assert.equal(g.duration,settle(k,z));assert.equal(g.ease(0),0);assert.equal(g.ease(1),1);
  for(let i=0;i<240;i++)assert(Math.abs(g.ease(i/240)-response(k,z,s.duration*i/240))<1e-10);
  for(let i=Math.ceil(s.duration*1000);i<2000;i++)assert(Math.abs(response(k,z,i/1000)-1)<=.0051);
}
assert.equal(stagger,.05);
assert.throws(()=>generate({...t,spatial:{...t.spatial,fast:{...t.spatial.fast,duration:{$type:'duration',$value:{value:.1,unit:'s'}}}}}));
assert.throws(()=>response(-1,1,0));assert.throws(()=>response(800,2,0));
if(!process.env.C8_READ_ONLY)fs.writeFileSync(new URL('./token-tests.json',import.meta.url),JSON.stringify({passed:true,deterministic:true,physicsUnits:true,gsapCssAnalyticParity:true,noDurationBounce:true},null,2));
console.log('Token generation, physics units, parity, rest bound and stale-input rejection passed');
