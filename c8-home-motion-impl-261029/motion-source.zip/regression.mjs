import {createRequire} from 'node:module';import fs from 'node:fs';
const require=createRequire(import.meta.url);const {chromium}=require('playwright');
const root=new URL('.',import.meta.url).pathname,browser=await chromium.launch({headless:true,...(process.env.CHROME_EXECUTABLE_PATH?{executablePath:process.env.CHROME_EXECUTABLE_PATH}:{})});
const results=[];
try{
 const p=await browser.newPage({viewport:{width:390,height:844}});await p.goto('http://127.0.0.1:8769/wire.html');await p.waitForFunction(()=>window.__c8Motion?.ready);
 await p.evaluate(()=>document.body.classList.add('no-annot'));
 for(const id of ['s1','s2','s3','ch01','ch02','ch03','ch04','bridge','ch05','s10','s12','s13']){await p.locator('#'+id).scrollIntoViewIfNeeded();await p.waitForTimeout(100);}
 const staticScenes=await p.evaluate(()=>window.__c8Motion.history.filter(h=>['s2','s3','s10','s13'].includes(h.section)));
 results.push({name:'static scenes have no entrance animation',pass:staticScenes.length===0,history:staticScenes});
 await p.locator('#ch05').scrollIntoViewIfNeeded();await p.waitForTimeout(150);await p.locator('#pSound').click();await p.waitForTimeout(80);
 const state=await p.locator('#pState').innerText(),sound=await p.locator('#pSound').innerText();results.push({name:'missing film never claims playback',pass:!state.includes('재생 중')&&sound==='소리 켜고 전체 보기',state,sound});
 await p.locator('[data-play="1"]').first().click();await p.waitForTimeout(100);
 const legacySound=await p.locator('#pSound').innerText(),legacyState=await p.locator('#pState').innerText();results.push({name:'legacy film selection cannot fake sound state',pass:legacySound==='소리 켜고 전체 보기'&&!legacyState.includes('재생 중'),legacySound,legacyState});
 await p.locator('#ch02-2 summary').click();await p.waitForTimeout(100);results.push({name:'nonvideo screen retains static label',pass:await p.locator('#ch02 .scr-in').isVisible()});
 await p.locator('#ch01 .motion-demo button').click();results.push({name:'upload reaches completed state',pass:await p.locator('#ch01 .motion-demo b').innerText().then(t=>t==='올림 완료')});
 await p.evaluate(()=>document.body.classList.add('rm'));results.push({name:'manual reduced-motion disables bar transition',pass:await p.locator('.topbar').evaluate(el=>getComputedStyle(el).transitionDuration==='0s')});
 await p.goto('http://127.0.0.1:8769/compare.html');await p.waitForFunction(()=>window.__compare?.ready);await p.evaluate(()=>window.__compare.seek(.033));
 const delta=await p.evaluate(()=>{const w=document.querySelector('.web-word'),r=document.querySelector('#reel').contentDocument.querySelector('.word');return Math.abs(new DOMMatrix(getComputedStyle(w).transform).m42-new DOMMatrix(getComputedStyle(r).transform).m42*document.querySelector('#reelStage').clientWidth/1080);});results.push({name:'comparison visible displacement matches',pass:delta<.1,deltaPx:delta});
 for(const mode of ['delayed','failed']){
  const net=await browser.newPage({viewport:{width:390,height:844}});let release,start;const started=new Promise(r=>start=r);
  await net.route('**/media.json',async r=>{await new Promise(resolve=>{release=resolve;start();});if(mode==='failed')await r.fulfill({status:503,body:'unavailable'});else await r.continue();});
  await net.goto('http://127.0.0.1:8769/wire.html',{waitUntil:'commit'});await started;await net.locator('[data-play="1"]').first().click();
  const early=await net.locator('#pState').innerText(),button=await net.locator('#pSound').innerText();
  release();await net.waitForFunction(()=>window.__c8Motion?.ready);
  const after=await net.locator('#pState').innerText();results.push({name:mode+' manifest cannot expose fake playback and recovers',pass:!early.includes('재생 중')&&!after.includes('재생 중')&&button==='소리 켜고 전체 보기',early,after});await net.close();
 }
 // Baseline and implementation measured sequentially in the same machine load, with the same CPU slowdown.
 const perf=[];
 for(const mode of ['baseline','implementation']){
  const page=await browser.newPage({viewport:{width:390,height:844}});const cdp=await page.context().newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
  await page.route('**/baseline.html',r=>r.fulfill({contentType:'text/html',body:fs.readFileSync(root+'original.html')}));
  await page.addInitScript(()=>{window.__loafs=[];new PerformanceObserver(l=>window.__loafs.push(...l.getEntries().map(e=>({startTime:e.startTime,duration:e.duration,blockingDuration:e.blockingDuration})))).observe({type:'long-animation-frame',buffered:true});});
  await page.goto('http://127.0.0.1:8769/'+(mode==='baseline'?'baseline.html':'wire.html'));await page.waitForFunction(mode==='baseline'?'!!window.__wf':'!!window.__c8Motion?.ready');await page.evaluate(()=>document.body.classList.add('no-annot'));
  const start=await page.evaluate(()=>performance.now());
  for(const id of ['s1','ch01','ch02','ch03','ch04','bridge','ch05','exp','s12']){await page.locator('#'+id).scrollIntoViewIfNeeded();await page.waitForTimeout(500);}
  perf.push(await page.evaluate(({mode,start})=>({mode,cpuSlowdown:4,rangeStart:start,rangeEnd:performance.now(),all:window.__loafs,motionRange:window.__loafs.filter(f=>f.startTime>=start)}),{mode,start}));await page.close();
 }
 if(!process.env.C8_READ_ONLY)fs.writeFileSync(root+'regression-tests.json',JSON.stringify({passed:results.every(r=>r.pass),results,performance:perf},null,2));console.log(JSON.stringify({results,performance:perf.map(p=>({mode:p.mode,all:p.all.length,motionRange:p.motionRange.length,ms:p.rangeEnd-p.rangeStart}))},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
}finally{await browser.close();}
