import {createRequire} from 'node:module';
import fs from 'node:fs';
const {chromium}=createRequire(import.meta.url)('playwright');
const root=new URL('.',import.meta.url).pathname;
const base=process.env.PREVIEW_URL||'http://127.0.0.1:8771';
const readonly=!!process.env.C8_READ_ONLY;
const browser=await chromium.launch({headless:true,...(process.env.CHROME_EXECUTABLE_PATH?{executablePath:process.env.CHROME_EXECUTABLE_PATH}:{})});
const results=[];
function assert(value,message){if(!value)throw Error(message);}
try{
 for(const width of [390,1440])for(const reducedMotion of ['no-preference','reduce']){
  const context=await browser.newContext({viewport:{width,height:900},reducedMotion});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  await page.goto(base+'/wire.html');await page.waitForFunction(()=>window.__c8Motion?.ready);
  await page.evaluate(()=>document.body.classList.add('no-annot'));
  const shell=page.locator('#ch02 .media-shell'),button=shell.locator('button');
  const initial=await page.evaluate(()=>window.__c8Motion.media[0].getState());
  assert(!initial.loaded,'Distant video loaded early');
  if(reducedMotion==='no-preference'){
   await page.evaluate(()=>{const s=window.__c8Motion.media[0].shell;scrollTo(0,s.getBoundingClientRect().top+scrollY-innerHeight-1100);});
   await page.waitForFunction(()=>window.__c8Motion.media[0].getState().near);
   const near=await page.evaluate(()=>({loaded:window.__c8Motion.media[0].getState().loaded,paused:window.__c8Motion.media[0].video.paused}));
   assert(near.loaded&&near.paused,'1200px preloading must stay paused before visibility');
  }
  await shell.scrollIntoViewIfNeeded();await page.waitForFunction(()=>window.__c8Motion.media[0].getState().visible);
  if(reducedMotion==='reduce'){
   const paused=await page.evaluate(()=>({paused:window.__c8Motion.media[0].video.paused,src:window.__c8Motion.media[0].video.getAttribute('src')}));
   assert(paused.paused&&paused.src===null,'Reduced motion must show poster without loading video');
  }else await page.waitForFunction(()=>!window.__c8Motion.media[0].video.paused&&window.__c8Motion.media[0].video.readyState>=2);
  const state=await page.evaluate(async()=>{
   const c=window.__c8Motion.media[0],v=c.video,img=new Image();img.src=v.poster;await img.decode();
   return {paused:v.paused,muted:v.muted,loop:v.loop,playsInline:v.playsInline,poster:v.poster,posterSize:[img.naturalWidth,img.naturalHeight],placeholderVisible:getComputedStyle(c.shell.querySelector('.media-poster')).display!=='none',overflow:document.documentElement.scrollWidth-innerWidth,noindex:document.querySelector('meta[name="robots"]').content.includes('noindex'),episode:{src:window.__c8Motion.media[1].video.getAttribute('src'),poster:window.__c8Motion.media[1].video.poster},videoCount:document.querySelectorAll('#ch02 video').length};
  });
  assert(state.muted&&state.loop&&state.playsInline,'Muted inline loop properties missing');
  assert(state.poster.endsWith('/media/respect-poster.jpg')&&state.posterSize[0]===360&&state.posterSize[1]===780,'Wrong or missing final-frame poster');
  assert(!state.placeholderVisible,'Placeholder text covers the approved poster');
  assert(state.overflow===0&&state.noindex&&state.videoCount===1,'Layout, indexing or duplicate video regression');
  assert(state.episode.src===null&&state.episode.poster==='','Unapproved episode changed');
  if(!readonly)await page.screenshot({path:root+(base.startsWith('https')?'live-':'local-')+`respect-${width}-${reducedMotion}.png`});
  if(reducedMotion==='reduce'){await button.click();await page.waitForFunction(()=>!window.__c8Motion.media[0].video.paused&&window.__c8Motion.media[0].video.readyState>=2);}
  const before=await page.evaluate(()=>window.__c8Motion.media[0].video.currentTime);
  await page.waitForFunction(t=>window.__c8Motion.media[0].video.currentTime>t+.1,before);
  await button.click();await page.waitForFunction(()=>window.__c8Motion.media[0].video.paused);
  await page.evaluate(()=>scrollTo(0,0));await page.waitForFunction(()=>!window.__c8Motion.media[0].getState().visible);
  await shell.scrollIntoViewIfNeeded();await page.waitForFunction(()=>window.__c8Motion.media[0].getState().visible);
  assert(await page.evaluate(()=>window.__c8Motion.media[0].video.paused),'User pause lost after viewport return');
  const episodeJson=await page.request.get(base+'/media.json').then(r=>r.json());assert(episodeJson.episode.src===null&&episodeJson.episode.poster===null,'Episode manifest changed');
  assert(errors.length===0,errors.join('; '));results.push({width,reducedMotion,passed:true,state,actualPlaybackAdvanced:true,pauseSurvivedViewport:true,errors});await context.close();
 }
 // Deny autoplay on the actual published player, then allow the user's play action.
 const context=await browser.newContext({viewport:{width:390,height:900}});
 await context.addInitScript(()=>{const original=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){return window.allowRespectPlay?original.call(this):Promise.reject(new DOMException('Test autoplay denial','NotAllowedError'));};});
 const p=await context.newPage();await p.goto(base+'/wire.html#ch02');await p.waitForFunction(()=>window.__c8Motion?.ready);await p.locator('#ch02 .media-shell').scrollIntoViewIfNeeded();
 await p.waitForFunction(()=>document.querySelector('#ch02 .media-state').textContent.includes('자동재생이 막혔어요'));
 assert(await p.locator('#ch02 .media-shell button').isEnabled(),'Blocked autoplay must expose enabled play');
 if(!readonly)await p.screenshot({path:root+(base.startsWith('https')?'live-':'local-')+'respect-autoplay-denied.png'});
 // Keep autoplay denied through Playwright's pre-click scrolling; unlock only on the actual user click.
 await p.evaluate(()=>document.addEventListener('click',e=>{if(e.target.closest('#ch02 .media-shell button'))window.allowRespectPlay=true;},{capture:true,once:true}));
 await p.locator('#ch02 .media-shell button').click();await p.waitForFunction(()=>!window.__c8Motion.media[0].video.paused&&window.__c8Motion.media[0].video.readyState>=2);
 results.push({autoplayDenied:true,manualRecovery:true,passed:true});await context.close();
 const result={passed:true,base,results};if(!readonly)fs.writeFileSync(root+(base.startsWith('https')?'live-respect.json':'local-respect.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}catch(e){if(!readonly)fs.writeFileSync(root+(base.startsWith('https')?'live-respect.json':'local-respect.json'),JSON.stringify({passed:false,results,error:e.message},null,2));throw e;}finally{await browser.close();}
