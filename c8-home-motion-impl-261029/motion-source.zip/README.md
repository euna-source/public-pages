# C8 홈 모션 구현 사본

확정 C안 여섯 스프링을 DTCG 2025.10 그룹 확장으로 보관합니다. duration은 0.5% 정착 기준의 파생값이며 motion 물리 스프링에는 전달하지 않습니다. 이 형식은 DTCG Community Group 보고서 기준이며 W3C 권고 표준이라는 뜻은 아닙니다.

```sh
npm run generate
npm test
npm run build
python3 -m http.server 8769 --bind 127.0.0.1 --directory preview
```

`preview/wire.html`은 기존 와이어의 사본입니다. `compare.html`은 CSS와 GSAP의 같은 시각 비교, `reel.html`은 6초 HyperFrames 자막·엔딩 샘플입니다. 샘플은 대표 편 완성본과 다릅니다.

브라우저 검증은 `npm install`과 `npx playwright install chromium` 뒤 `npm run verify`로 실행합니다. 다른 설치된 Chrome을 쓰면 `CHROME_EXECUTABLE_PATH`를 지정합니다. `test-video.mjs`는 공개 권한이 확인된 로컬 시험 영상을 루트의 `respect-optimized.mp4`로 준비한 뒤 실행합니다. 샐리가 공개 사용을 승인한 압축본과 끝 장면 포스터는 preview/media에 포함했습니다. 원본 녹화는 포함하지 않았습니다. 시험 서버는 로컬 호스트에만 바인딩합니다.

영상 연결은 `preview/media.json`의 `src`, `poster`, `fullSrc`로 합니다. 원본이 없는 자리는 null과 확인 전 문구를 유지합니다. 리스펙트는 공개 사용 승인 뒤 압축본과 끝 장면 포스터를 연결했습니다. 대표 편 원본·완성 포스터가 없는 자리는 확인 전 표시를 유지합니다.

정지 구간: 2·3·10·13. 구간별 주인공: 첫 카드, 올리기 화면, 리스펙트, 프로필 틀, 노크 말풍선, 다리 어절, 대표 편, 프로필 결과, 끝 로고. 공간 움직임은 transform, 효과는 opacity만 씁니다. 튕김은 C8 버튼과 로고에 제한하고 영상 위 제어에는 적용하지 않습니다.

원본 와이어는 정적 피니셔 87/110이며 주석·조건부 앵커·로파이 스타일 때문에 출고 디자인 기준에 미달합니다. 이번 작업은 원본 디자인 보존과 모션 사본 검증 범위입니다. 실제 브라우저에서 390·1440 넘침·오류는 없었습니다. 요약 페이지는 피니셔 기준을 통과했습니다.

남은 항목: 대표 편 6~8초 미리보기와 전체 영상·포스터, 영상 디코딩 포함 낮은 부하 재측정, 저사양 Android·iOS 저전력 실기기. 홈 운영 배포와 앱 main 반영은 별도 승인 범위입니다.

기준: https://www.designtokens.org/tr/2025.10/format/
