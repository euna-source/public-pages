"""Write explicitly synthetic, manually specified MY/settings calculation inputs."""
import csv
import datetime as dt
import json
from pathlib import Path
from verify_capture import OBS_COLUMNS, EVENT_COLUMNS
from verify_aggregation import REPORT_COLUMNS, sha

# Independently specified; never derive report expectations from received events.
STEPS = [
    ('MY 내 프로필에서 기록 시작', 'my_profile', 'none'),
    ('설정 홈 열기', 'settings_home', 'my_profile'),
    ('계정 열기', 'settings_account', 'settings_home'),
    ('설정 홈으로 뒤로가기', 'settings_home', 'settings_account'),
]
EXPECTED = [('my_profile', 'none', '1'), ('settings_home', 'my_profile', '1'),
            ('settings_account', 'settings_home', '1'), ('settings_home', 'settings_account', '1')]


def write_csv(path, fields, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_example(folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    proof = folder / 'synthetic-evidence.txt'
    proof.write_text('SYNTHETIC CALCULATION EXAMPLE. No app was run. No GA event was received. No report was queried.\n')
    observations, events, report_rows = [], [], []
    for os in ('ios', 'aos'):
        for i, (action, name, previous) in enumerate(STEPS):
            start = dt.datetime(2026, 9, 12, 0, 0, i * 5, tzinfo=dt.timezone.utc)
            base = dict(run_id=os+'-example', platform=os, build_id=os+'-synthetic',
                        scenario='my_settings', step_id=f'{i+1:02}')
            observations.append(dict(base, action=action, start_time=start.isoformat(),
                                     end_time=(start+dt.timedelta(seconds=4)).isoformat(),
                                     evidence_file=proof.name, evidence_sha256=sha(proof)))
            events.append(dict(base, sequence=str(i+1), timestamp=(start+dt.timedelta(seconds=1)).isoformat(),
                               event_name='screen_view', screen_name=name, screen_schema_version='3',
                               screen_visit_id=os+'-visit-'+str(i+1), previous_screen=previous, params_json='{}'))
        report_rows.extend(dict(platform=os, screen_name=name, previous_screen=previous, views=count) for name, previous, count in EXPECTED)
    write_csv(folder/'observations.csv', OBS_COLUMNS, observations)
    write_csv(folder/'events.csv', EVENT_COLUMNS, events)
    write_csv(folder/'report.csv', REPORT_COLUMNS, report_rows)
    capture = dict(kind='synthetic_fixture', receiver='bigquery', reviewer='synthetic example',
                   captured_at='2026-09-12T00:01:00Z', builds={os:os+'-synthetic' for os in ('ios','aos')},
                   received_events_sha256=sha(folder/'events.csv'))
    report = dict(kind='synthetic_fixture', source_kind='bigquery_query',
                  source='Synthetic manually specified expected counts; no query executed.',
                  reviewer='synthetic example', extracted_at='2026-09-12T00:01:00Z',
                  same_capture_scope=True, unit='screen_view_event_count',
                  report_sha256=sha(folder/'report.csv'), capture_events_sha256=sha(folder/'events.csv'),
                  evidence_file=proof.name, evidence_sha256=sha(proof))
    for name, data in [('capture.json', capture), ('report.json', report)]:
        (folder/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
