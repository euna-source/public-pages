#!/usr/bin/env python3
"""Reconcile a selected, observed test run with a separately exported count report.

This validates supplied files, not their external authenticity or production coverage.
"""
import argparse
import collections
import hashlib
import json
import sys
from pathlib import Path
import verify_capture as receipt

ROOT = Path(__file__).resolve().parent
REPORT_COLUMNS = ['platform', 'screen_name', 'previous_screen', 'views']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare_counts(events, rows):
    """Keep all received screen views; never silently deduplicate or filter names."""
    expected = collections.Counter((e['platform'], e['screen_name'], e['previous_screen'])
                                   for e in events if e['event_name'] == 'screen_view')
    actual, errors = {}, []
    for row in rows:
        key = (row.get('platform', ''), row.get('screen_name', ''), row.get('previous_screen', ''))
        value = row.get('views', '')
        if key[0] not in ('ios', 'aos') or not key[1] or not key[2]:
            errors.append('invalid report dimension: ' + str(key))
        if key in actual:
            errors.append('duplicate report group: ' + str(key))
        if not isinstance(value, str) or not value.isascii() or not value.isdigit():
            errors.append('invalid report count: ' + str(key))
            continue
        actual[key] = int(value)
    if set(expected) != set(actual):
        errors.append('report group coverage mismatch')
    for key in sorted(set(expected) | set(actual)):
        if expected.get(key) != actual.get(key):
            errors.append('report count mismatch: ' + str(key))
    counts = [dict(platform=os, screen_name=name, previous_screen=previous, received_views=count,
                   report_views=actual.get((os, name, previous)))
              for (os, name, previous), count in sorted(expected.items())]
    return counts, errors


def verify(capture_dir, report_file, selected=None, test_fixture=False, root=ROOT):
    result = dict(passed=False, scope='unverified', release_ready=False,
                  production_aggregation_verified=False, product_impact_verified=False,
                  errors=[], counts=[])
    try:
        capture_dir, report_file = Path(capture_dir).resolve(), Path(report_file).resolve()
        events_file = capture_dir / 'events.csv'
        obs = receipt.read_csv(capture_dir / 'observations.csv', receipt.OBS_COLUMNS)
        events = receipt.read_csv(events_file, receipt.EVENT_COLUMNS)
        capture = json.loads((capture_dir / 'capture.json').read_text())
        report = json.loads(report_file.with_suffix('.json').read_text())
        rows = receipt.read_csv(report_file, REPORT_COLUMNS)
        scenarios = json.loads((root / 'scenarios.json').read_text())
        selection = set(selected or [s['id'] for s in scenarios['scenarios']])
        if any(row.get('scenario') not in selection for row in obs+events):
            raise ValueError('unselected scenario in capture; supply one complete capture for the selected set')
        if capture.get('received_events_sha256') != sha(events_file):
            raise ValueError('capture events checksum mismatch')
        synthetic = capture.get('kind') == 'synthetic_fixture'
        if test_fixture != synthetic:
            raise ValueError('synthetic capture requires --test-fixture; actual capture forbids it')
        if report.get('kind') != ('synthetic_fixture' if synthetic else 'report_export'):
            raise ValueError('report kind does not match capture kind')
        if report.get('source_kind') != 'bigquery_query':
            raise ValueError('only BigQuery raw-count reports support exact reconciliation')
        if not report.get('source') or not report.get('reviewer'):
            raise ValueError('report source or reviewer missing')
        receipt.instant(report.get('extracted_at', ''))
        if report.get('same_capture_scope') is not True:
            raise ValueError('same execution/build/time scope must be confirmed')
        if report.get('unit') != 'screen_view_event_count':
            raise ValueError('report must count screen_view events, not users or sessions')
        if report.get('report_sha256') != sha(report_file):
            raise ValueError('report checksum mismatch')
        if report.get('capture_events_sha256') != sha(events_file):
            raise ValueError('report belongs to different raw capture')
        evidence = report.get('evidence_file', '')
        evidence_path = (report_file.parent / evidence).resolve()
        if not evidence or not evidence_path.is_relative_to(report_file.parent) or not evidence_path.is_file():
            raise ValueError('report evidence missing or outside report directory')
        if report.get('evidence_sha256') != sha(evidence_path):
            raise ValueError('report evidence checksum mismatch')
        checked = receipt.verify(json.loads((root / 'screen-contract.json').read_text()),
                                 scenarios,
                                 obs, events, capture, capture_dir, selected=selected,
                                 allow_synthetic=test_fixture)
        result['errors'].extend(checked['errors'])
        result['counts'], count_errors = compare_counts(events, rows)
        result['errors'].extend(count_errors)
        result['received_screen_views'] = sum(r['received_views'] for r in result['counts'])
        result['distinct_screen_names'] = len({r['screen_name'] for r in result['counts']})
        totals = collections.Counter()
        settings_origins = {os:{} for os in ('ios','aos')}
        for row in result['counts']:
            totals[(row['platform'],row['screen_name'])] += row['received_views']
            if row['screen_name'] == 'settings_home':
                settings_origins[row['platform']][row['previous_screen']] = row['received_views']
        result['screen_totals'] = [dict(platform=os,screen_name=name,views=count) for (os,name),count in sorted(totals.items())]
        result['settings_origins'] = settings_origins
        result['settings_share'] = {}
        result['settings_origin_shares'] = {}
        for os in ('ios','aos'):
            numerator = totals.get((os,'settings_home'),0)
            denominator = sum(count for (platform,_),count in totals.items() if platform==os)
            result['settings_share'][os] = dict(numerator=numerator,denominator=denominator,
                                               ratio=numerator/denominator if denominator else None)
            result['settings_origin_shares'][os] = {previous:dict(numerator=count,denominator=numerator,
                                                               ratio=count/numerator if numerator else None)
                                                    for previous,count in settings_origins[os].items()}
        result['selected_scenarios'] = sorted(selection)
        result['source_kind'] = report['source_kind']
        result['capture_receiver'] = capture.get('receiver')
        result['scope'] = ('synthetic_aggregation_test' if synthetic else
                           'selected_run_counts_only')
        result['passed'] = not result['errors']
        result['inputs'] = dict(events_sha256=sha(events_file), report_sha256=sha(report_file))
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        result['errors'].append(str(error))
    result['limitation'] = ('선택한 조작의 수신과 제출된 보고서 횟수만 대조합니다. 출처·조회 범위의 진위, '
                            '일반 운영 데이터의 누락·지연·필터, 실제 개선은 담당자가 별도로 확인해야 합니다.')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture_dir', type=Path)
    parser.add_argument('report_file', type=Path)
    parser.add_argument('--scenario', action='append')
    parser.add_argument('--test-fixture', action='store_true')
    args = parser.parse_args()
    result = verify(args.capture_dir, args.report_file, args.scenario, args.test_fixture)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
