import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import aggregation_example as example
import verify_aggregation as aggregation


class AggregationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        example.write_example(self.folder)

    def verify(self, test=True):
        return aggregation.verify(self.folder, self.folder/'report.csv', ['my_settings'], test, ROOT)

    def mutate_csv(self, name, transform):
        path = self.folder/name
        with path.open(newline='') as stream:
            reader = csv.DictReader(stream)
            fields, rows = reader.fieldnames, list(reader)
        transform(rows)
        example.write_csv(path, fields, rows)
        # Update genuine integrity metadata so semantic rejection is tested independently.
        report_path = self.folder/'report.json'
        report = json.loads(report_path.read_text())
        if name == 'events.csv':
            capture_path = self.folder/'capture.json'
            capture = json.loads(capture_path.read_text())
            capture['received_events_sha256'] = aggregation.sha(path)
            capture_path.write_text(json.dumps(capture))
            report['capture_events_sha256'] = aggregation.sha(path)
        else:
            report['report_sha256'] = aggregation.sha(path)
        report_path.write_text(json.dumps(report))

    def reject(self, expected):
        result = self.verify()
        self.assertFalse(result['passed'])
        self.assertIn(expected, '\n'.join(result['errors']))
        self.assertFalse(result['production_aggregation_verified'])

    def test_return_visit_counts_twice_but_screen_kind_once(self):
        result = self.verify()
        self.assertTrue(result['passed'], result['errors'])
        self.assertEqual(result['received_screen_views'], 8)
        self.assertEqual(result['distinct_screen_names'], 3)
        for row in result['screen_totals']:
            self.assertEqual(row['views'], 2 if row['screen_name']=='settings_home' else 1)
        for os in ('ios','aos'):
            self.assertEqual(result['settings_origins'][os], {'my_profile':1,'settings_account':1})
            self.assertEqual(result['settings_share'][os], {'numerator':2,'denominator':4,'ratio':0.5})
            for value in result['settings_origin_shares'][os].values():
                self.assertEqual(value, {'numerator':1,'denominator':2,'ratio':0.5})
        self.assertEqual(result['scope'], 'synthetic_aggregation_test')
        self.assertFalse(result['release_ready'])
        self.assertFalse(result['production_aggregation_verified'])

    def test_synthetic_cannot_be_live_evidence(self):
        result = self.verify(test=False)
        self.assertFalse(result['passed'])
        self.assertIn('requires --test-fixture', '\n'.join(result['errors']))

    def test_same_name_deduplication_is_wrong(self):
        self.mutate_csv('report.csv', lambda rows: rows[3].update(views='0'))
        self.reject('report count mismatch')

    def test_duplicate_raw_cannot_be_hidden_by_report(self):
        self.mutate_csv('events.csv', lambda rows: rows.append(dict(rows[1])))
        self.reject('duplicate event sequence')

    def test_duplicate_with_fresh_visit_id_and_matching_report_rejected(self):
        self.mutate_csv('events.csv', lambda rows: rows.append(dict(rows[1], sequence='5', screen_visit_id='fresh-duplicate')))
        self.mutate_csv('report.csv', lambda rows: rows[1].update(views='2'))
        self.reject('screen_view count mismatch')

    def test_one_os_report_rejected(self):
        self.mutate_csv('report.csv', lambda rows: rows.__setitem__(slice(None), [r for r in rows if r['platform']=='ios']))
        self.reject('report group coverage mismatch')

    def test_extra_unknown_group_rejected(self):
        self.mutate_csv('report.csv', lambda rows: rows.append(dict(platform='ios', screen_name='my_page', previous_screen='none', views='0')))
        self.reject('report group coverage mismatch')

    def test_duplicate_report_group_rejected(self):
        self.mutate_csv('report.csv', lambda rows: rows.append(dict(rows[0])))
        self.reject('duplicate report group')

    def test_fraction_negative_and_empty_counts_rejected(self):
        for bad in ['1.5', '-1', '']:
            with self.subTest(bad=bad):
                example.write_example(self.folder)
                self.mutate_csv('report.csv', lambda rows: rows[0].update(views=bad))
                self.reject('invalid report count')

    def test_tampered_report_rejected(self):
        path = self.folder/'report.csv'
        path.write_text(path.read_text()+'\n')
        self.reject('report checksum mismatch')

    def test_different_capture_rejected(self):
        path = self.folder/'report.json'
        data = json.loads(path.read_text()); data['capture_events_sha256'] = 'wrong'
        path.write_text(json.dumps(data))
        self.reject('different raw capture')

    def test_users_are_not_screen_view_counts(self):
        path = self.folder/'report.json'
        data = json.loads(path.read_text()); data['unit'] = 'users'
        path.write_text(json.dumps(data))
        self.reject('not users or sessions')

    def test_missing_report_evidence_rejected(self):
        path = self.folder/'report.json'
        data = json.loads(path.read_text()); data['evidence_file'] = 'missing.txt'
        path.write_text(json.dumps(data))
        self.reject('report evidence missing')

    def test_unselected_scenario_rejected_before_aggregation(self):
        self.mutate_csv('events.csv', lambda rows: rows.append(dict(rows[0], scenario='home_profile')))
        result = self.verify()
        self.assertFalse(result['passed'])
        self.assertIn('unselected scenario', '\n'.join(result['errors']))
        self.assertEqual(result['counts'], [])

    def test_ga4_interface_report_not_compared_as_raw_counts(self):
        path = self.folder/'report.json'
        data = json.loads(path.read_text()); data['source_kind'] = 'ga4_report'
        path.write_text(json.dumps(data))
        self.reject('only BigQuery raw-count')

    def test_report_previous_screen_is_independently_checked(self):
        self.mutate_csv('report.csv', lambda rows: rows[3].update(previous_screen='my_info_home'))
        self.reject('report group coverage mismatch')


if __name__ == '__main__':
    unittest.main()
