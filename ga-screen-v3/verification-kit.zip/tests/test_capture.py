import copy
import csv
import datetime as dt
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import verify_capture as receipt


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.contract = json.loads((ROOT / 'screen-contract.json').read_text())
        self.scenarios = json.loads((ROOT / 'scenarios.json').read_text())
        self.obs, self.events = [], []
        proof = self.root / 'synthetic-action-evidence.txt'
        proof.write_text('SYNTHETIC CHECKER TEST. No app was run and no event was received.')
        digest = hashlib.sha256(proof.read_bytes()).hexdigest()
        # Expected journeys are manually authored separately from build.py.
        for os in ('ios', 'aos'):
            for si, scenario in enumerate(self.scenarios['scenarios']):
                run = os + '-' + scenario['id']
                seq = 0
                for i, step in enumerate(scenario['steps']):
                    start = dt.datetime(2026, 9, 12, 0, si, i * 5, tzinfo=dt.timezone.utc)
                    end = start + dt.timedelta(seconds=4)
                    base = dict(run_id=run, platform=os, build_id=os+'-fixture', scenario=scenario['id'], step_id=step['id'])
                    self.obs.append(dict(base, action=step['action'], start_time=start.isoformat(), end_time=end.isoformat(), evidence_file=proof.name, evidence_sha256=digest))
                    for exp in step['views']:
                        seq += 1
                        self.events.append(dict(base, sequence=str(seq), timestamp=(start+dt.timedelta(seconds=1)).isoformat(), event_name='screen_view', screen_name=exp['name'], screen_schema_version='3', screen_visit_id=run+'-'+str(seq), previous_screen=exp['previous'], params_json=json.dumps(exp.get('params', {}))))
        self.meta = dict(kind='synthetic_fixture', receiver='firebase_debugview', reviewer='test harness', captured_at='2026-09-12T00:00:00Z', builds={'ios':'ios-fixture','aos':'aos-fixture'}, received_events_sha256='set-by-cli-writer')

    def verify(self, **kwargs):
        return receipt.verify(self.contract, self.scenarios, self.obs, self.events, self.meta, self.root, allow_synthetic=True, **kwargs)

    def reject(self, expected):
        result = self.verify()
        self.assertFalse(result['passed'])
        self.assertIn(expected, '\n'.join(result['errors']))
        self.assertFalse(result['release_ready'])

    def test_valid_fixture_is_only_checker_evidence(self):
        result = self.verify()
        self.assertTrue(result['passed'], result['errors'])
        self.assertEqual(result['scope'], 'synthetic_checker_test')
        self.assertFalse(result['release_ready'])

    def test_empty(self):
        self.obs, self.events = [], []
        self.reject('empty received events')

    def test_one_os(self):
        self.obs = [o for o in self.obs if o['platform'] == 'ios']
        self.events = [e for e in self.events if e['platform'] == 'ios']
        self.reject('missing action observations')

    def test_missing_view(self):
        self.events.pop(1)
        self.reject('screen_view count mismatch')

    def test_duplicate_view(self):
        self.events.append(copy.deepcopy(self.events[1]))
        self.reject('duplicate event sequence')

    def test_duplicate_with_new_visit_id(self):
        event = dict(self.events[1], sequence='99', screen_visit_id='fresh-but-duplicate')
        self.events.append(event)
        self.reject('screen_view count mismatch')

    def test_retired_name(self):
        self.events[0]['screen_name'] = 'my_page'
        self.reject('retired or reserved screen')

    def test_korean_screen_name(self):
        self.events[0]['screen_name'] = '홈'
        self.reject('retired or reserved screen')

    def test_reserved_name(self):
        self.events[0]['screen_name'] = 'contacts_my_club'
        self.reject('retired or reserved screen')

    def test_wrong_schema(self):
        self.events[0]['screen_schema_version'] = '2'
        self.reject('schema mismatch')

    def test_wrong_previous(self):
        self.events[1]['previous_screen'] = 'my_profile'
        self.reject('wrong previous_screen')

    def test_reverse_sequence(self):
        self.events[0]['sequence'], self.events[1]['sequence'] = self.events[1]['sequence'], self.events[0]['sequence']
        self.reject('screen sequence reversed')

    def test_spurious_parent_view_on_background_return(self):
        step = next(o for o in self.obs if o['platform']=='ios' and o['scenario']=='home_profile' and o['step_id']=='06')
        self.events.append(dict(self.events[0], step_id='06', sequence='99', timestamp=step['start_time'], screen_visit_id='new-background-visit'))
        self.reject('screen_view count mismatch')

    def test_bad_parameter(self):
        e = next(e for e in self.events if e['screen_name']=='portfolio_create')
        e['params_json'] = '{"media_type":"unknown"}'
        self.reject('unregistered parameter value')

    def test_required_parameter_missing(self):
        e = next(e for e in self.events if e['screen_name']=='portfolio_create')
        e['params_json'] = '{}'
        self.reject('expected parameter missing')

    def test_mixed_build(self):
        self.events[1]['build_id'] = 'different-build'
        self.reject('build or run mismatch')

    def test_evidence_tampered(self):
        (self.root / 'synthetic-action-evidence.txt').write_text('modified')
        self.reject('action evidence checksum mismatch')

    def test_missing_observation(self):
        self.obs.pop(2)
        self.reject('missing action observations')

    def test_outside_time_window(self):
        self.events[0]['timestamp'] = '2025-01-01T00:00:00Z'
        self.reject('outside action time window')

    def test_reused_visit_id(self):
        self.events[1]['screen_visit_id'] = self.events[0]['screen_visit_id']
        self.reject('reused screen visit id')

    def test_wrong_event_cannot_replace_screen_view(self):
        self.events[0]['event_name'] = 'screen_enter'
        self.reject('screen_view count mismatch')

    def test_synthetic_blocked_in_live_mode(self):
        result = receipt.verify(self.contract, self.scenarios, self.obs, self.events, self.meta, self.root)
        self.assertFalse(result['passed'])
        self.assertIn('synthetic fixture cannot verify live receipt', result['errors'])

    def write_capture(self):
        for name, columns, rows in [('events', receipt.EVENT_COLUMNS, self.events), ('observations', receipt.OBS_COLUMNS, self.obs)]:
            with (self.root / (name+'.csv')).open('w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=columns)
                writer.writeheader()
                writer.writerows(rows)
        self.meta['received_events_sha256'] = hashlib.sha256((self.root / 'events.csv').read_bytes()).hexdigest()
        (self.root / 'capture.json').write_text(json.dumps(self.meta))

    def cli(self):
        return subprocess.run([sys.executable, str(ROOT/'verify_capture.py'), str(self.root), '--test-fixture'], capture_output=True, text=True)

    def test_cli_valid_fixture(self):
        self.write_capture()
        result = self.cli()
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)

    def test_cli_event_csv_tampered(self):
        self.write_capture()
        with (self.root/'events.csv').open('a') as f:
            f.write('\n')
        result = self.cli()
        self.assertEqual(result.returncode, 1)
        self.assertIn('checksum differs', result.stdout)



if __name__ == "__main__":
    unittest.main()
