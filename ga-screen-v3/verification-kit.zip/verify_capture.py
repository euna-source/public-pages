#!/usr/bin/env python3
"""Compare independently observed actions with received screen_view events.

A passed comparison is scoped to selected scenarios; never a release approval.
"""
import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OBS_COLUMNS = ["run_id", "platform", "build_id", "scenario", "step_id", "action", "start_time", "end_time", "evidence_file", "evidence_sha256"]
EVENT_COLUMNS = ["run_id", "platform", "build_id", "scenario", "step_id", "sequence", "timestamp", "event_name", "screen_name", "screen_schema_version", "screen_visit_id", "previous_screen", "params_json"]


def instant(value):
    value = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if value.tzinfo is None:
        raise ValueError("timezone required")
    return value


def read_csv(path, required):
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing = set(required) - set(reader.fieldnames or [])
        if missing:
            raise ValueError(path.name + " missing columns: " + ", ".join(sorted(missing)))
        return list(reader)


def verify(contract, scenarios, observations, events, metadata, evidence_root, selected=None, allow_synthetic=False):
    errors = []
    if not observations:
        errors.append("empty observations")
    if not events:
        errors.append("empty received events")
    if metadata.get("kind") == "synthetic_fixture" and not allow_synthetic:
        errors.append("synthetic fixture cannot verify live receipt")
    if metadata.get("kind") not in ("received_capture", "synthetic_fixture"):
        errors.append("unknown capture kind")
    if metadata.get("receiver") not in ("firebase_debugview", "bigquery"):
        errors.append("capture is not a supported receiver source")
    if not metadata.get("reviewer") or not metadata.get("captured_at"):
        errors.append("capture reviewer or time missing")
    all_scenarios = {s["id"]: s for s in scenarios["scenarios"]}
    selected = set(selected or all_scenarios)
    if not selected or not selected <= set(all_scenarios):
        errors.append("invalid scenario selection")
        return {"passed": False, "errors": errors, "release_ready": False}
    active = {s["key"]: s for s in contract["screens"] if not s.get("reserved")}
    expected = {(os, sid, step["id"]): step for os in ("ios", "aos") for sid in selected for step in all_scenarios[sid]["steps"]}
    obs_by_step = {}
    run_builds = {}
    scenario_runs = collections.defaultdict(set)
    windows = {}
    for o in observations:
        ident = (o.get("platform"), o.get("scenario"), o.get("step_id"))
        if ident not in expected:
            errors.append("unexpected observation: " + str(ident))
            continue
        if ident in obs_by_step:
            errors.append("duplicate observation: " + str(ident))
        obs_by_step[ident] = o
        if o.get("action") != expected[ident]["action"]:
            errors.append("observation action mismatch: " + str(ident))
        if not o.get("run_id") or not o.get("build_id"):
            errors.append("run/build identity missing: " + str(ident))
        rb = (o.get("platform"), o.get("run_id"))
        if rb in run_builds and run_builds[rb] != o.get("build_id"):
            errors.append("mixed builds in run: " + str(rb))
        run_builds[rb] = o.get("build_id")
        scenario_runs[(o.get("platform"), o.get("scenario"))].add(o.get("run_id"))
        if metadata.get("builds", {}).get(o.get("platform")) != o.get("build_id"):
            errors.append("capture build pin mismatch: " + str(ident))
        try:
            start, end = instant(o.get("start_time", "")), instant(o.get("end_time", ""))
            if end <= start:
                raise ValueError
            windows[ident] = (start, end)
        except (ValueError, TypeError):
            errors.append("invalid observation time window: " + str(ident))
        file = o.get("evidence_file", "")
        path = (evidence_root / file).resolve()
        if not file or not path.is_relative_to(evidence_root.resolve()) or not path.is_file():
            errors.append("missing action evidence: " + str(ident))
        elif hashlib.sha256(path.read_bytes()).hexdigest() != o.get("evidence_sha256"):
            errors.append("action evidence checksum mismatch: " + str(ident))
    missing = set(expected) - set(obs_by_step)
    if missing:
        errors.append("missing action observations: " + str(sorted(missing)))
    for ident, runs in scenario_runs.items():
        if len(runs) != 1:
            errors.append("scenario mixes capture runs: " + str(ident))
    for os in ("ios", "aos"):
        for sid in selected:
            prior_end = None
            for step in all_scenarios[sid]["steps"]:
                window = windows.get((os, sid, step["id"]))
                if window:
                    if prior_end and window[0] < prior_end:
                        errors.append("observation windows overlap or reverse: " + os + "/" + sid)
                    prior_end = window[1]
    # Actual source CSV hash is bound to the capture; filenames alone are not proof.
    if not metadata.get("received_events_sha256"):
        errors.append("received events checksum missing")
    grouped = collections.defaultdict(list)
    visit_ids = set()
    sequence_ids = set()
    for event in events:
        ident = (event.get("platform"), event.get("scenario"), event.get("step_id"))
        o = obs_by_step.get(ident)
        if o is None:
            errors.append("event outside observed steps: " + str(ident))
            continue
        if event.get("run_id") != o.get("run_id") or event.get("build_id") != o.get("build_id"):
            errors.append("event/observation build or run mismatch: " + str(ident))
        try:
            seq = int(event.get("sequence", ""))
            if seq < 1:
                raise ValueError
        except (ValueError, TypeError):
            errors.append("invalid event sequence: " + str(ident))
            continue
        seqid = (event.get("platform"), event.get("run_id"), seq)
        if seqid in sequence_ids:
            errors.append("duplicate event sequence: " + str(seqid))
        sequence_ids.add(seqid)
        try:
            timestamp = instant(event.get("timestamp", ""))
            window = windows.get(ident)
            if not window or not window[0] <= timestamp < window[1]:
                errors.append("event outside action time window: " + str(ident))
        except (ValueError, TypeError):
            errors.append("invalid event timestamp: " + str(ident))
        if event.get("event_name") != "screen_view":
            # The capture may contain other events. Never use screen_enter as a
            # substitute for a missing screen_view.
            continue
        name = event.get("screen_name", "")
        if name not in active:
            errors.append("unknown, retired or reserved screen: " + name)
        if event.get("screen_schema_version") != "3":
            errors.append("schema mismatch: " + str(ident))
        visit = event.get("screen_visit_id", "")
        visit_ident = (event.get("platform"), event.get("run_id"), visit)
        if not visit or visit_ident in visit_ids:
            errors.append("missing or reused screen visit id: " + str(ident))
        visit_ids.add(visit_ident)
        try:
            params = json.loads(event.get("params_json") or "{}")
            if not isinstance(params, dict):
                raise ValueError
        except (ValueError, TypeError):
            errors.append("invalid params JSON: " + str(ident))
            params = {}
        for param, value in params.items():
            allowed = active.get(name, {}).get("params", {}).get(param)
            if allowed is None or value not in allowed:
                errors.append("unregistered parameter value: " + name + "." + param)
        grouped[ident].append((seq, event, params))
    for ident, step in expected.items():
        got = sorted(grouped[ident], key=lambda x: x[0])
        want = step["views"]
        if len(got) != len(want):
            errors.append("screen_view count mismatch: " + str(ident) + f" expected={len(want)} got={len(got)}")
        for (_, event, params), exp in zip(got, want):
            if event.get("screen_name") != exp["name"]:
                errors.append("wrong screen at " + str(ident) + ": " + event.get("screen_name", ""))
            if event.get("previous_screen") != exp["previous"]:
                errors.append("wrong previous_screen at " + str(ident))
            for param, value in exp.get("params", {}).items():
                if params.get(param) != value:
                    errors.append("expected parameter missing/wrong: " + str(ident) + "." + param)
    # Sequence order is checked across steps, not just within each step.
    for os in ("aos", "ios"):
        for sid in selected:
            order = []
            for step in all_scenarios[sid]["steps"]:
                order.extend(x[0] for x in sorted(grouped[(os, sid, step["id"])], key=lambda x: x[0]))
            if order != sorted(order):
                errors.append("screen sequence reversed: " + os + "/" + sid)
    return dict(passed=not errors, scope="synthetic_checker_test" if metadata.get("kind") == "synthetic_fixture" else "selected_scenarios_only", selected_scenarios=sorted(selected), required_platforms=["aos", "ios"], observed_actions=len(observations), received_screen_views=sum(len(v) for v in grouped.values()), errors=errors, release_ready=False, limitation="자료의 실제 출처와 조작 여부는 담당자가 수신 화면·녹화와 대조해야 합니다. 이 결과만으로 전체 계약·최신 빌드·운영 수집을 승인하지 않습니다.")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("capture_dir", type=Path)
    p.add_argument("--scenario", action="append")
    p.add_argument("--test-fixture", action="store_true")
    args = p.parse_args()
    try:
        root = args.capture_dir.resolve()
        obs = read_csv(root / "observations.csv", OBS_COLUMNS)
        events = read_csv(root / "events.csv", EVENT_COLUMNS)
        metadata = json.loads((root / "capture.json").read_text())
        digest = hashlib.sha256((root / "events.csv").read_bytes()).hexdigest()
        if metadata.get("received_events_sha256") != digest:
            raise ValueError("events.csv checksum differs from capture.json")
        result = verify(json.loads((ROOT / "screen-contract.json").read_text()), json.loads((ROOT / "scenarios.json").read_text()), obs, events, metadata, root, selected=args.scenario, allow_synthetic=args.test_fixture)
        if args.test_fixture and metadata.get("kind") != "synthetic_fixture":
            result["passed"] = False
            result["errors"].append("--test-fixture requires synthetic_fixture kind")
    except (OSError, ValueError, KeyError) as e:
        result = dict(passed=False, errors=[str(e)], release_ready=False)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
