# Cre8orClub 이메일 v3 — 참고 사례와 적용

Pinterest 검색은 로그인 창에 가려 사례를 상세 확인하지 못했다. Pinterest를 디자인 참고 근거로 사용하지 않았다. 아래 Really Good Emails의 실제 이메일 이미지 4개를 브라우저에서 열고 캡처해 검토했다. 타사 이미지·문구는 복사하지 않았다.

| 실제 이메일 | 관찰 | 이번 시안 적용 |
|---|---|---|
| [Beefree — You’re the ultimate winner](https://reallygoodemails.com/emails/smiles-davis-youre-the-ultimate-winner) | 첫 화면의 큰 시상식 타이틀과 과감한 색면 | 초록 면에 큰 WEEKLY / BEST 타이틀 |
| [Musicbed — 2025 Genre Awards](https://reallygoodemails.com/emails/2025-musicbed-awards-by-genre) | 검정 배경, 큰 제목, 일정한 수상 부문 정렬 | 두 수상 부문을 동일 규격의 결과 패널로 정렬 |
| [Product Hunt — Golden Kitty Winners](https://reallygoodemails.com/emails/golden-kitty-winners) | 하나의 강한 수상 키비주얼 | 수상 결과 자체를 시각 중심으로 사용. 긴 후속 목록은 제외 |
| [Strava — July Walk 30K Challenge completed](https://reallygoodemails.com/emails/july-walk-30k-challenge-completed) | 축하 뒤 개인 성과 숫자 그리드 | 2위·5위를 크게, 부문·경품을 숫자 가까이 배치 |

## 기존과 달라진 구조

- 기존: 검정 인사 헤더 → 흰 본문 선정 내역 목록 → 검정 총액 박스 → 설명 문단.
- v3: Cre8orClub·United in Crazy 마스트헤드 → 초록 시상식 타이틀 → 두 부문 순위 패널 → 상품권 티켓 띠 → 수령 3단계 → 브랜드 푸터.
- 브랜드 표기: Cre8orClub. 홈페이지의 United in Crazy 슬로건을 상단과 하단에 반영.
- 서체: Gmarket Sans Bold와 Pretendard 400·600·700. 웹폰트 미지원 환경은 시스템 글꼴로 대체.
- 순위·금액·번호 확인 후 1영업일·등록 번호 발송·변경 선택지·담당자 별도 문자·문자 회신 안내 유지.
- 수상자명·주차·금액은 발송 전 실제 내역으로 교체해야 한다. 실제 발송·수신함별 표시는 아직 검증하지 않았다.

브랜드 근거: [공식 홈페이지](https://cre8orclub.com/) · [Weekly Best 이벤트](https://view.cre8orclub.com/share/event/weekly-best)
