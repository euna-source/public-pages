async function waitForGmailAccount(){
 for(let i=0;i<120;i++){
  if(location.origin==='https://mail.google.com'&&/^\/mail\/u\/\d+\/$/.test(location.pathname)&&document.title.toLowerCase().includes('support@cre8orclub.com'))return {ok:true,pathname:location.pathname};
  await new Promise(r=>setTimeout(r,250));
 }
 return {ok:false,error:'support@cre8orclub.com으로 로그인한 뒤 다시 눌러 주세요.'};
}
/* This function is serialized into the new Gmail tab; keep all helpers inside it. */
async function insertFinalDraft(payload){
 try{
  if(location.origin!=='https://mail.google.com')throw Error('Gmail 화면에서만 연결할 수 있어요.');
  let body;
  for(let i=0;i<120;i++){
   body=document.querySelector('[contenteditable="true"][role="textbox"][aria-label]');
   if(body&&document.title.toLowerCase().includes('support@cre8orclub.com')&&new URL(location.href).searchParams.get('su')===payload.subject)break;
   body=null;await new Promise(r=>setTimeout(r,250));
  }
  if(!body)throw Error('support@cre8orclub.com으로 로그인한 뒤 다시 눌러 주세요.');
  if(body.dataset.c8DraftRequest===payload.requestId)return {ok:true,requestId:payload.requestId};
  const make=n=>{
   if(typeof n.text==='string')return document.createTextNode(n.text);
   const el=document.createElement(n.tag);for(const [k,v] of Object.entries(n.attrs))el.setAttribute(k,v);
   for(const child of n.children)el.appendChild(make(child));return el;
  };
  const fragment=document.createDocumentFragment();for(const n of payload.nodes)fragment.appendChild(make(n));
  const text=node=>node.nodeType===3?node.textContent:node.nodeType===1&&node.tagName==='IMG'?(node.getAttribute('alt')||''):[...node.childNodes].map(text).join('');
  const norm=s=>s.replace(/\s+/g,' ').trim();const expected=norm(text(fragment));
  body.focus();body.replaceChildren(fragment);
  body.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertFromPaste'}));body.dispatchEvent(new Event('change',{bubbles:true}));
  if(norm(text(body))!==expected)throw Error('최종 문안을 모두 넣었는지 확인하지 못했어요. Gmail 화면을 확인해 주세요.');
  body.dataset.c8DraftRequest=payload.requestId;
  return {ok:true,requestId:payload.requestId,account:'support@cre8orclub.com',tables:body.querySelectorAll('table').length};
 }catch(e){return {ok:false,error:e.message};}
}
if(typeof module==='object')module.exports={insertFinalDraft,waitForGmailAccount};
