(function(root){
 const ORIGIN='https://euna-source.github.io';
 const paths=['/public-pages/c8-content-seeding/','/public-pages/c8-content-seeding/index.html','/public-pages/c8-content-seeding/content-seeding-email-instagram-dm.html','/public-pages/c8-content-seeding/content-seeding-editor.html'];
 function allowedSender(url){try{const u=new URL(url);return u.origin===ORIGIN&&paths.includes(u.pathname);}catch(e){return false;}}
 const tags=new Set('table tbody tr td th thead tfoot caption colgroup col div p span strong b em i u s br img a ol ul li blockquote hr h1 h2 h3 h4 h5 h6 pre code'.split(' '));
 const attrs=new Set('style href src alt width height cellpadding cellspacing border role align valign lang dir'.split(' '));
 function validateNodes(nodes,depth=0,budget={n:0,bytes:0}){
  if(!Array.isArray(nodes)||depth>35)throw Error('지원하지 않는 양식 구조예요.');
  for(const n of nodes){
   if(!n||++budget.n>10000)throw Error('양식이 너무 커요.');
   if(typeof n.text==='string'){budget.bytes+=n.text.length;if(budget.bytes>600000||n.text.length>300000)throw Error('문장이 너무 길어요.');continue;}
   if(!tags.has(n.tag)||!n.attrs||typeof n.attrs!=='object')throw Error('지원하지 않는 양식 요소예요.');
   for(const [k,v] of Object.entries(n.attrs)){
    budget.bytes+=String(v).length;if(budget.bytes>600000||!attrs.has(k)||typeof v!=='string'||v.length>20000)throw Error('지원하지 않는 양식 속성이에요.');
    if(['href','src'].includes(k)&&!/^https:\/\//i.test(v)&&!(k==='href'&&/^mailto:/i.test(v)))throw Error('지원하지 않는 메일 링크예요.');
   }
   validateNodes(n.children,depth+1,budget);
  }
  return nodes;
 }
 function payload(m){
  if(!m||m.type!=='c8-create-html-draft'||typeof m.requestId!=='string'||!/^[\w-]{8,100}$/.test(m.requestId))throw Error('잘못된 작성 요청이에요.');
  const p=m.payload;if(!p||typeof p.to!=='string'||!/^\S+@[^\s@]+\.[^\s@]+$/.test(p.to)||/[\r\n,;]/.test(p.to))throw Error('받는 주소를 확인해 주세요.');
  if(typeof p.subject!=='string'||!p.subject.trim()||p.subject.length>500||/[\r\n]/.test(p.subject))throw Error('메일 제목을 확인해 주세요.');
  if(!Array.isArray(p.nodes)||!p.nodes.some(n=>n?.tag==='table'))throw Error('최종 메일 양식을 확인해 주세요.');
  return {to:p.to,subject:p.subject,nodes:validateNodes(p.nodes),requestId:m.requestId};
 }
 function composeUrl(p,accountPath='/mail/'){if(!/^\/mail\/(?:u\/\d+\/)?$/.test(accountPath))throw Error('Gmail 계정을 확인해 주세요.');return 'https://mail.google.com'+accountPath+'?authuser=support%40cre8orclub.com&view=cm&fs=1&to='+encodeURIComponent(p.to)+'&su='+encodeURIComponent(p.subject);}
 const api={allowedSender,payload,composeUrl,validateNodes};if(typeof module==='object')module.exports=api;else root.C8DraftProtocol=api;
})(globalThis);
