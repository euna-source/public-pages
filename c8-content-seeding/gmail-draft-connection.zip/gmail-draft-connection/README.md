# Cre8orClub 메일 양식 연결

공개 콘텐츠 시딩 편집기의 ‘메일로 보내기’에서 현재 편집한 최종 문안과 디자인을 support Gmail 새 작성창에 자동으로 넣습니다. 메일 발송은 사람이 직접 합니다.

설치: ZIP 압축 해제 → Aside 또는 Chrome 확장 프로그램 화면 → 개발자 모드 → 압축해제된 확장 프로그램 로드 → 이 manifest.json이 있는 폴더 선택 → 공개 편집기 새로고침.

필요 권한은 Gmail 사이트 접근과 작성 화면에 코드 실행입니다. 브라우저의 사이트 접근 권한 범위는 Gmail 전체지만, 이 코드의 동작은 사용자가 편집기에서 요청한 새 작성창에 한정합니다. 받은편지함 조회, 자동 발송, 별도 서버 전송, 로그인 정보 보관 기능은 없습니다. support 계정에 로그인되어 있어야 합니다. 연결이 실패하면 빈 양식으로 완료 처리하지 않습니다.

허용 편집기는 euna-source.github.io/public-pages/c8-content-seeding/의 지정된 HTML 파일뿐입니다. 내려받은 편집기(file URL)에서는 기존 복사 기능을 사용하거나 공개 웹 편집기에서 연결 기능을 사용합니다.

검증 범위: 삽입 함수의 실제 Gmail 자동 입력, 편집기 연결의 모의 응답, 단위 시험을 확인했습니다. 설치 후 버튼부터 Gmail까지의 실제 연결 검증은 설치 승인 후에 진행합니다.

API 근거: https://developer.chrome.com/docs/extensions/develop/concepts/messaging#external-webpage · https://developer.chrome.com/docs/extensions/reference/api/scripting
