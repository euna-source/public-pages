importScripts('protocol.js','compose.js');
const pending=new Map();
async function runInGmail(tabId,func,args=[]){
 const deadline=Date.now()+35000;
 while(Date.now()<deadline){
  const state=await chrome.tabs.get(tabId);
  if(state.status==='complete'&&state.url?.startsWith('https://mail.google.com/')){
   try{const r=await chrome.scripting.executeScript({target:{tabId},func,args});return r[0]?.result;}catch(e){if(Date.now()+500>=deadline)throw e;}
  }
  await new Promise(r=>setTimeout(r,250));
 }
 throw Error('Gmail 연결이 늦어지고 있어요. 로그인 상태를 확인해 주세요.');
}
chrome.runtime.onMessageExternal.addListener((message,sender,respond)=>{
 if(!C8DraftProtocol.allowedSender(sender.url)){respond({ok:false,error:'허용된 편집기에서만 연결할 수 있어요.'});return false;}
 if(message?.type==='c8-draft-ping'){respond({ok:true,version:1});return false;}
 let payload;try{payload=C8DraftProtocol.payload(message);}catch(e){respond({ok:false,error:e.message});return false;}
 let job=pending.get(payload.requestId);
 if(!job){job=(async()=>{
  let tab;
  try{
   // No recipient or subject enters a Gmail tab before the account is verified.
   tab=await chrome.tabs.create({url:'https://mail.google.com/mail/?authuser=support%40cre8orclub.com&view=cm&fs=1',active:true});
   const account=await runInGmail(tab.id,waitForGmailAccount);
   if(!account?.ok)throw Error(account?.error||'support 계정을 확인해 주세요.');
   await chrome.tabs.update(tab.id,{url:C8DraftProtocol.composeUrl(payload,account.pathname)});
   const result=await runInGmail(tab.id,insertFinalDraft,[payload]);
   if(!result?.ok)throw Error(result?.error||'최종 양식을 넣지 못했어요.');
   return result;
  }catch(e){if(tab?.id)try{await chrome.tabs.remove(tab.id);}catch(closeError){}return {ok:false,error:e.message};}
 })();pending.set(payload.requestId,job);setTimeout(()=>pending.delete(payload.requestId),120000);}
 job.then(respond,e=>respond({ok:false,error:e.message}));return true;
});
